import numpy as np
from scales_rrhc import ScalesRRHC
from data_utils import generate_random_weights, save_weights_to_csv, read_weights_from_csv
import matplotlib.pyplot as plt

def run_test_case(weights, num_restarts, iterations_per_restart, test_name):
    """
    Run a test case with specific parameters and save results.
    
    Args:
        weights: List of weights to partition
        num_restarts: Number of random restarts
        iterations_per_restart: Number of iterations per restart
        test_name: Name for saving results
    """
    print(f"\nRunning test case: {test_name}")
    print(f"Weights: {weights}")
    print(f"Parameters: {num_restarts} restarts, {iterations_per_restart} iterations per restart")
    
    solver = ScalesRRHC(weights, num_restarts, iterations_per_restart)
    best_solution, best_fitness = solver.solve()
    
    print(f"Best solution found: {best_solution}")
    print(f"Best fitness achieved: {best_fitness}")
    
    # Save results
    solver.plot_fitness_history(f"fitness_history_{test_name}.png")
    
    # Calculate and print group sums
    group_a = [w for w, s in zip(weights, best_solution) if s == 0]
    group_b = [w for w, s in zip(weights, best_solution) if s == 1]
    print(f"Group A sum: {sum(group_a)} (weights: {group_a})")
    print(f"Group B sum: {sum(group_b)} (weights: {group_b})")
    print("-" * 80)

def main():
    # Test Case 1: Small set of weights with few restarts
    weights1 = [10, 20, 30, 40, 50]
    run_test_case(weights1, num_restarts=5, iterations_per_restart=500, test_name="small_set")

    # Test Case 2: Large set of weights with more restarts
    weights2 = generate_random_weights(size=20, min_weight=1, max_weight=100)
    run_test_case(weights2, num_restarts=15, iterations_per_restart=1000, test_name="large_set")

    # Test Case 3: Weights with large differences
    weights3 = [1, 2, 3, 98, 99, 100]
    run_test_case(weights3, num_restarts=10, iterations_per_restart=800, test_name="large_differences")

    # Test Case 4: Many small weights
    weights4 = generate_random_weights(size=30, min_weight=1, max_weight=10)
    run_test_case(weights4, num_restarts=20, iterations_per_restart=1500, test_name="many_small_weights")

    # Test Case 5: Weights with patterns
    weights5 = [i * 10 for i in range(1, 11)]  # [10, 20, 30, ..., 100]
    run_test_case(weights5, num_restarts=12, iterations_per_restart=1000, test_name="patterned_weights")

    # Save all test weights to CSV for future reference
    all_weights = {
        "small_set": weights1,
        "large_set": weights2,
        "large_differences": weights3,
        "many_small_weights": weights4,
        "patterned_weights": weights5
    }
    
    for name, weights in all_weights.items():
        save_weights_to_csv(f"weights_{name}.csv", weights)

def compare_parameters():
    """Compare different parameter settings with the same weights."""
    weights = generate_random_weights(size=15, min_weight=1, max_weight=100)
    
    # Test different numbers of restarts
    restart_values = [5, 10, 20]
    plt.figure(figsize=(15, 5))
    
    for i, num_restarts in enumerate(restart_values, 1):
        solver = ScalesRRHC(weights, num_restarts=num_restarts, iterations_per_restart=1000)
        best_solution, best_fitness = solver.solve()
        
        plt.subplot(1, 3, i)
        plt.plot(range(1, num_restarts + 1), solver.fitness_history, 'b-', label='Fitness per Restart')
        plt.plot(range(1, num_restarts + 1), 
                [min(solver.fitness_history[:j+1]) for j in range(num_restarts)],
                'r--', label='Best Fitness So Far')
        plt.xlabel('Restart Number')
        plt.ylabel('Fitness')
        plt.title(f'{num_restarts} Restarts')
        plt.legend()
        plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('parameter_comparison.png')
    plt.close()

if __name__ == "__main__":
    print("Running test cases with different weight configurations...")
    main()
    
    print("\nComparing different parameter settings...")
    compare_parameters()
    
    print("\nAll tests completed! Check the generated PNG files for visualizations.") 