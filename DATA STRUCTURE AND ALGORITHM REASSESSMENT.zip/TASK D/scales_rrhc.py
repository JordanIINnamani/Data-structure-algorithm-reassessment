import random
import csv
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt

class ScalesRRHC:
    def __init__(self, weights: List[int], num_restarts: int = 10, iterations_per_restart: int = 1000):
        """
        Initialize the RRHC solver for the Scales Problem.
        
        Args:
            weights: List of weights to partition
            num_restarts: Number of random restarts
            iterations_per_restart: Number of iterations per restart
        """
        self.weights = weights
        self.num_restarts = num_restarts
        self.iterations_per_restart = iterations_per_restart
        self.best_solution = None
        self.best_fitness = float('inf')
        self.fitness_history = []

    def generate_random_solution(self) -> List[int]:
        """Generate a random binary solution."""
        return [random.randint(0, 1) for _ in range(len(self.weights))]

    def calculate_fitness(self, solution: List[int]) -> int:
        """
        Calculate the fitness (absolute difference between group sums).
        
        Args:
            solution: Binary list representing group assignments
            
        Returns:
            Absolute difference between the sums of the two groups
        """
        group_a_sum = sum(w for w, s in zip(self.weights, solution) if s == 0)
        group_b_sum = sum(w for w, s in zip(self.weights, solution) if s == 1)
        return abs(group_a_sum - group_b_sum)

    def get_neighbor(self, solution: List[int]) -> List[int]:
        """
        Generate a neighboring solution by flipping one random bit.
        
        Args:
            solution: Current solution
            
        Returns:
            New solution with one bit flipped
        """
        neighbor = solution.copy()
        flip_index = random.randrange(len(solution))
        neighbor[flip_index] = 1 - neighbor[flip_index]
        return neighbor

    def hill_climbing(self) -> Tuple[List[int], int]:
        """
        Perform hill climbing from a random initial solution.
        
        Returns:
            Tuple of (best solution found, best fitness achieved)
        """
        current_solution = self.generate_random_solution()
        current_fitness = self.calculate_fitness(current_solution)
        
        for _ in range(self.iterations_per_restart):
            neighbor = self.get_neighbor(current_solution)
            neighbor_fitness = self.calculate_fitness(neighbor)
            
            if neighbor_fitness < current_fitness:
                current_solution = neighbor
                current_fitness = neighbor_fitness
                
        return current_solution, current_fitness

    def solve(self) -> Tuple[List[int], int]:
        """
        Perform Random Restart Hill Climbing.
        
        Returns:
            Tuple of (best solution found, best fitness achieved)
        """
        for restart in range(self.num_restarts):
            solution, fitness = self.hill_climbing()
            self.fitness_history.append(fitness)
            
            if fitness < self.best_fitness:
                self.best_solution = solution
                self.best_fitness = fitness
                
        return self.best_solution, self.best_fitness

    def plot_fitness_history(self, save_path: str = None):
        """
        Plot the fitness history across restarts.
        
        Args:
            save_path: Optional path to save the plot
        """
        plt.figure(figsize=(10, 6))
        plt.plot(range(1, self.num_restarts + 1), self.fitness_history, 'b-', label='Fitness per Restart')
        plt.plot(range(1, self.num_restarts + 1), 
                [min(self.fitness_history[:i+1]) for i in range(self.num_restarts)],
                'r--', label='Best Fitness So Far')
        plt.xlabel('Restart Number')
        plt.ylabel('Fitness (Absolute Difference)')
        plt.title('Fitness History Across Restarts')
        plt.legend()
        plt.grid(True)
        
        if save_path:
            plt.savefig(save_path)
        plt.close()

def main():
    # Example usage
    weights = [i * 10 for i in range(1, 11)]  # [10, 20, 30, ..., 100]
    num_restarts = 12
    iterations = 1000
    
    # Create and run RRHC solver
    solver = ScalesRRHC(weights, num_restarts=num_restarts, iterations_per_restart=iterations)
    best_solution, best_fitness = solver.solve()
    
    # Print results
    print(f"Best solution found: {best_solution}")
    print(f"Best fitness achieved: {best_fitness}")
    
    # Plot results
    solver.plot_fitness_history("fitness_history.png")

if __name__ == "__main__":
    main() 