import csv
from typing import List, Tuple
import numpy as np

def read_weights_from_csv(filepath: str) -> List[int]:
    """
    Read weights from a CSV file.
    
    Args:
        filepath: Path to the CSV file containing weights
        
    Returns:
        List of weights
    """
    weights = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            weights.extend([int(x) for x in row])
    return weights

def write_results_to_csv(filepath: str, results: List[Tuple[List[int], int]]):
    """
    Write results to a CSV file.
    
    Args:
        filepath: Path to save the CSV file
        results: List of tuples containing (solution, fitness)
    """
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Solution', 'Fitness'])
        for solution, fitness in results:
            writer.writerow([solution, fitness])

def generate_random_weights(size: int, min_weight: int = 1, max_weight: int = 100) -> List[int]:
    """
    Generate a list of random weights.
    
    Args:
        size: Number of weights to generate
        min_weight: Minimum weight value
        max_weight: Maximum weight value
        
    Returns:
        List of random weights
    """
    return list(np.random.randint(min_weight, max_weight + 1, size=size))

def save_weights_to_csv(filepath: str, weights: List[int]):
    """
    Save weights to a CSV file.
    
    Args:
        filepath: Path to save the CSV file
        weights: List of weights to save
    """
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(weights) 