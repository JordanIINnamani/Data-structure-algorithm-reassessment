# Scales Problem - Random Restart Hill Climbing Implementation

This project implements a solution to the Scales Problem using Random Restart Hill Climbing (RRHC). The Scales Problem involves partitioning a set of weights into two groups to minimize the absolute difference between their sums.

## Features

- Implementation of Random Restart Hill Climbing algorithm
- Support for custom weight sets
- CSV input/output for weights and results
- Visualization of fitness history across restarts
- Configurable number of restarts and iterations

## Requirements

- Python 3.7+
- Dependencies listed in `requirements.txt`

## Installation

1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Basic Usage

```python
from scales_rrhc import ScalesRRHC

# Create a list of weights
weights = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# Initialize and run the solver
solver = ScalesRRHC(weights, num_restarts=10, iterations_per_restart=1000)
best_solution, best_fitness = solver.solve()

# Print results
print(f"Best solution found: {best_solution}")
print(f"Best fitness achieved: {best_fitness}")

# Plot results
solver.plot_fitness_history("fitness_history.png")
```

### Using Data Utilities

```python
from data_utils import generate_random_weights, save_weights_to_csv, read_weights_from_csv

# Generate random weights
weights = generate_random_weights(size=10, min_weight=1, max_weight=100)

# Save weights to CSV
save_weights_to_csv("weights.csv", weights)

# Read weights from CSV
loaded_weights = read_weights_from_csv("weights.csv")
```

## Algorithm Details

The implementation uses the following approach:

1. **Solution Representation**: Binary list (0/1) indicating group assignment for each weight
2. **Fitness Function**: Absolute difference between the sums of the two groups
3. **Neighborhood Structure**: Single bit flip (moving one weight to the other group)
4. **Restart Strategy**: Multiple random restarts with hill climbing from each starting point

## Results

The algorithm tracks and visualizes:
- Fitness value for each restart
- Best fitness achieved so far
- Final solution and its fitness

Results are saved as:
- CSV files for numerical data
- PNG files for fitness history plots 