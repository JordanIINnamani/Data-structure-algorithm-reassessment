from typing import List
import random
from dataclasses import dataclass
from typing import Optional


@dataclass
class StallConfiguration:
    """Data class to hold stall configuration parameters."""
    positions: List[int]
    stall_count: int
    cow_count: int

    def __post_init__(self):
        """Validate the configuration after initialization."""
        if not self.positions:
            raise ValueError("Stall positions cannot be empty")
        if self.stall_count <= 0:
            raise ValueError("Stall count must be positive")
        if self.cow_count <= 0:
            raise ValueError("Cow count must be positive")
        if self.cow_count > self.stall_count:
            raise ValueError("Cow count cannot be greater than stall count")
        if len(self.positions) != self.stall_count:
            raise ValueError("Number of positions must match stall count")


def aggressive_cows(config: StallConfiguration) -> int:
    """
    Find the maximum minimum distance between cows that can be placed in stalls.
    
    Args:
        config: StallConfiguration object containing stall positions and counts
        
    Returns:
        int: Maximum possible minimum distance between any two cows
        
    Raises:
        ValueError: If the configuration is invalid
    """
    positions = sorted(config.positions)  # Ensure the stalls are sorted
    low = 0
    high = positions[-1] - positions[0]
    result = 0
    
    while low <= high:
        mid = (low + high) // 2
        if _is_distance_valid(positions, mid, config.cow_count):
            result = mid
            low = mid + 1
        else:
            high = mid - 1
    return result


def _is_distance_valid(positions: List[int], min_distance: int, cow_count: int) -> bool:
    """
    Check if it's possible to place cows with the given minimum distance.
    
    Args:
        positions: List of sorted stall positions
        min_distance: Minimum distance required between cows
        cow_count: Number of cows to place
        
    Returns:
        bool: True if cows can be placed with given minimum distance, False otherwise
    """
    if cow_count == 0:
        return True
        
    cows_placed = 1
    last_position = positions[0]
    
    for pos in positions[1:]:
        if pos - last_position >= min_distance:
            cows_placed += 1
            last_position = pos
            if cows_placed == cow_count:
                return True
    return False


def generate_random_stalls(stall_count: int, max_position: int = 100) -> List[int]:
    """
    Generate random unique stall positions.
    
    Args:
        stall_count: Number of stalls to generate
        max_position: Maximum possible position value
        
    Returns:
        List[int]: List of unique stall positions
    """
    if stall_count > max_position + 1:
        raise ValueError("Stall count cannot be greater than max_position + 1")
    return sorted(random.sample(range(max_position + 1), stall_count))


def main():
    """Main function to demonstrate the aggressive cows algorithm."""
    try:
        # Example configuration
        stall_count = 5
        cow_count = 3
        
        # Generate random stall positions
        positions = generate_random_stalls(stall_count)
        print(f"Generated Stall Positions: {positions}")
        
        # Create configuration
        config = StallConfiguration(
            positions=positions,
            stall_count=stall_count,
            cow_count=cow_count
        )
        
        # Calculate maximum minimum distance
        max_min_distance = aggressive_cows(config)
        print(f"Maximum minimum distance between cows: {max_min_distance}")
        
    except ValueError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


if __name__ == "__main__":
    main()