from typing import List

def bubble_sort(arr: List[int]) -> None:
    """
    Sort the given list using bubble sort algorithm.
    The list is sorted in-place in ascending order.
    
    Args:
        arr: List of integers to be sorted
    """
    n = len(arr)
    for i in range(n):
        # Flag to optimize if no swaps occur
        swapped = False
        
        # Last i elements are already in place
        for j in range(0, n - i - 1):
            # Swap if current element is greater than next element
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        
        # If no swapping occurred in this pass, array is sorted
        if not swapped:
            break 