from typing import List

class BinaryHeap:
    def __init__(self, arr: List[int]):
        """
        Initialize a binary heap with the given array.
        
        Args:
            arr: List of integers to be converted into a heap
        """
        self.heap = arr.copy()
        self.size = len(arr)
        self._build_heap()
    
    def _parent(self, i: int) -> int:
        """Return the index of the parent of node at index i."""
        return (i - 1) // 2
    
    def _left_child(self, i: int) -> int:
        """Return the index of the left child of node at index i."""
        return 2 * i + 1
    
    def _right_child(self, i: int) -> int:
        """Return the index of the right child of node at index i."""
        return 2 * i + 2
    
    def _heapify(self, i: int):
        """
        Heapify the subtree rooted at index i.
        
        Args:
            i: Index of the root of the subtree to heapify
        """
        smallest = i
        left = self._left_child(i)
        right = self._right_child(i)
        
        # Find the smallest among node i and its children
        if left < self.size and self.heap[left] < self.heap[smallest]:
            smallest = left
        
        if right < self.size and self.heap[right] < self.heap[smallest]:
            smallest = right
        
        # If the smallest is not the root, swap and heapify the affected subtree
        if smallest != i:
            self.heap[i], self.heap[smallest] = self.heap[smallest], self.heap[i]
            self._heapify(smallest)
    
    def _build_heap(self):
        """Build a min heap from the given array."""
        # Start from the last non-leaf node and heapify all nodes in reverse order
        for i in range(self.size // 2 - 1, -1, -1):
            self._heapify(i)
    
    def sort(self) -> List[int]:
        """
        Sort the array using heap sort.
        
        Returns:
            List[int]: The sorted array in ascending order
        """
        # Create a copy of the heap to avoid modifying the original
        sorted_arr = self.heap.copy()
        size = self.size
        
        # Extract elements one by one
        for i in range(size - 1, 0, -1):
            # Move current root to end
            sorted_arr[0], sorted_arr[i] = sorted_arr[i], sorted_arr[0]
            
            # Reduce heap size and heapify the root
            self.size = i
            self.heap = sorted_arr
            self._heapify(0)
        
        # Restore original size
        self.size = size
        return sorted_arr 