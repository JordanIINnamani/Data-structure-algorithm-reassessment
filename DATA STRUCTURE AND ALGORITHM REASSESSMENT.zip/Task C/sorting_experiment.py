import time
import random
import csv
from typing import List, Callable
import numpy as np
from bubble_sort import bubble_sort
from binary_heap import BinaryHeap

def generate_dataset(size: int) -> List[int]:
    """Generate a random dataset of given size."""
    return [random.randint(1, 1000000) for _ in range(size)]

def write_dataset_to_csv(data: List[int], filename: str):
    """Write dataset to a CSV file."""
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(data)

def read_dataset_from_csv(filename: str) -> List[int]:
    """Read dataset from a CSV file."""
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        return [int(x) for x in next(reader)]

def write_results_to_csv(results: List[dict], filename: str):
    """Write experiment results to a CSV file."""
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['dataset_size', 'algorithm', 'run_number', 'time_ms'])
        writer.writeheader()
        writer.writerows(results)

def run_experiment(dataset: List[int], algorithm: Callable, algorithm_name: str, 
                  run_number: int, dataset_size: int) -> dict:
    """Run a single experiment and return the results."""
    # Create a copy of the dataset to avoid modifying the original
    data_copy = dataset.copy()
    
    # Measure execution time
    start_time = time.time_ns()
    algorithm(data_copy)
    end_time = time.time_ns()
    
    # Convert nanoseconds to milliseconds
    execution_time_ms = (end_time - start_time) / 1_000_000
    
    return {
        'dataset_size': dataset_size,
        'algorithm': algorithm_name,
        'run_number': run_number,
        'time_ms': execution_time_ms
    }

def main():
    # Dataset sizes as specified in the requirements
    dataset_sizes = [1000, 5000, 15000, 20000, 25000, 30000, 35000, 40000]
    num_runs = 3  # Number of runs per dataset
    
    results = []
    
    for size in dataset_sizes:
        print(f"\nProcessing dataset size: {size}")
        
        # Generate dataset
        dataset = generate_dataset(size)
        
        # Save dataset to CSV
        write_dataset_to_csv(dataset, f'dataset_{size}.csv')
        
        # Run experiments for both algorithms
        for run in range(1, num_runs + 1):
            # Bubble Sort
            bubble_result = run_experiment(
                dataset, 
                bubble_sort, 
                'Bubble Sort',
                run,
                size
            )
            results.append(bubble_result)
            
            # Binary Heap
            heap_result = run_experiment(
                dataset,
                lambda x: BinaryHeap(x).sort(),
                'Binary Heap',
                run,
                size
            )
            results.append(heap_result)
            
            print(f"Run {run} completed for size {size}")
    
    # Write results to CSV
    write_results_to_csv(results, 'experiment_results.csv')
    
    # Print summary
    print("\nExperiment Summary:")
    print("==================")
    for size in dataset_sizes:
        size_results = [r for r in results if r['dataset_size'] == size]
        bubble_times = [r['time_ms'] for r in size_results if r['algorithm'] == 'Bubble Sort']
        heap_times = [r['time_ms'] for r in size_results if r['algorithm'] == 'Binary Heap']
        
        print(f"\nDataset size: {size}")
        print(f"Bubble Sort - Average: {np.mean(bubble_times):.2f}ms, Std Dev: {np.std(bubble_times):.2f}ms")
        print(f"Binary Heap - Average: {np.mean(heap_times):.2f}ms, Std Dev: {np.std(heap_times):.2f}ms")

if __name__ == "__main__":
    main() 